# Import the numpy library, which is a Python library for scientific computing, providing multi-dimensional array objects and various mathematical functions
import numpy as np


# Define a function named `init_random` to randomly initialize the distribution of residents in a city
# According to the Schelling model, this is equivalent to randomly placing agents from different groups at the start of the simulation
def init_random(Q, H, rho0):
    """
    Randomly initialize a city by placing agents according to a given global density.

    Parameters:
    - Q (int): Number of neighborhoods (blocks) - the number of communities/blocks
    - H (int): Capacity of each neighborhood - the maximum capacity of each community (number of residents it can hold)
    - rho0 (float): Initial average density (0 < rho0 <= 1) - the initial average density (a decimal between 0 and 1)

    Returns:
    - occupied (np.ndarray): Array of length Q, indicating the number of agents in each neighborhood
      Returns an array of length Q, representing the number of existing residents in each community
    """
    # Calculate the total number of residents to be placed: number of communities × capacity per community × initial density
    # Example: 36 communities × 100 capacity × 0.5 density = 1800 residents
    N = int(Q * H * rho0)

    # Create an array of length Q, filled with 0s, indicating that all communities are initially empty
    # dtype=int specifies that the array elements are of integer type
    occupied = np.zeros(Q, dtype=int)

    # Start looping to place each resident; the loop runs for the total number of residents N
    for _ in range(N):
        # Randomly select a community index (a random integer between 0 and Q-1)
        q = np.random.randint(Q)
        
        # Check if the selected community is full (number of residents has reached capacity H)
        # If full, re-select until a non-full community is found
        while occupied[q] >= H:
            q = np.random.randint(Q)
        
        # Add one resident to the found non-full community
        occupied[q] += 1

    # Return a copy of the resident distribution array (using copy() ensures an independent copy is returned to prevent accidental modification of the original data)
    return occupied.copy()